function yourName(){
    let yourName = "Kevin";
    if(confirm("Are you " + yourName + "?")){
        console.log("Hello " + yourName);
    }else{
        console.log("Then what is your name?");
    }
    let number = 99;
    if(number== 99){
        console.log("The number is correct");
    }else{
        console.log("The number is not correct");
    }
}
function numberSOrG(){
    let num1 = 1;
    let num2 = 2;
    if(num1 < num2){
        console.log("Num1 is smaller then num2");
    }else if(num1 > num2){
        console.log("Num1 is greaetr than num2");
    }else{
        console.log("The numbers are equal");
    }
}
function driveLicense(){
    let age = Number(prompt("Enter your age"));
    if(age>=18){
        console.log("Congratulations you can have a license")
    }else{
        console.log("Sorry, you are too young to get a driving license")
    }
}
function guessNumber(){
    let numRam = Math.floor(Math.random() * 10)+1;
    console.log(numRam);
    let numGuess = Number(prompt("Guess a number bewtenn 1 to 10"));
    if(numRam == numGuess){
        console.log("Congratulations, you guessed the number");
    }else{
        console.log("Sorry, that's not correct. The number was: " + numRam);
    }
}
let username="zamorakevin@gmail.com";
let password="hello";
function logIn(){
    let usernameInput = prompt("Enter your username"); 
    let passwordInput = prompt("Enter your password");
    if(usernameInput == username && passwordInput == password){
        document.getElementById("msg").innerHTML="Welcome to the system";
    }else{
        document.getElementById("msg").innerHTML="Invalid credentials";
    }
}