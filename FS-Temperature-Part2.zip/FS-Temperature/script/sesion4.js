//for loop
/*for(let i=10;i<=100;i+=10){
    console.log("This is the number: " + i);
}
function multiplicationTable(num){
    document.write(`<h2>Multiplication table for ${num}</h2>`)
    for(let i=1;i<=10;i++){
        document.write(`<p>${i} x ${num}: ${i*num}</p>`);
    }
}
multiplicationTable(1);

//while
let i=1;
while(i<6){
    console.log(i);
    i++;
}

//do
let j=0;
do{
    console.log(j);
    j++
}while(j<10);


let targetNumber = Math.floor(Math.random() * 10)+1;
let userGuess = Number(prompt("Guess the numbers betwwn 1 and 10:"));

while(userGuess !== targetNumber){
    userGuess = Number(prompt("Incorrect!! Try again. Guess the numbers betwwn 1 and 10:"));
}
console.log("Congratulations!");

let correctPass = "Hello";
let attempts=3;
while(attempts>0){
    let guessPass = prompt("Guess the user password to enter:")
    if(guessPass == correctPass)
    {
        console.log("Congratulations!");
        break;
    }else{
        console.log("Incorrect! Try again.")
        attempts--;
    }
}*/

for(let i=1;i<=20;i++){
    if(i%3===0 && i%5===0){
        console.log("FizzBuzz");
    }else if(i%5===0){
        console.log("Buzz");
    }else if(i%3===0){
        console.log("Fizz");
    }else{
        console.log(i);
    }
}

